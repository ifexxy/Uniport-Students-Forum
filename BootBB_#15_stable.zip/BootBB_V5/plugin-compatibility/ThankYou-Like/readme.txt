Integrating with Thank You/Like plugin

1. Install Thank You/Like from https://community.mybb.com/mods.php?action=view&pid=360
2. Go to the "Templates & Style" tab
3. Click on your BootBB theme
4. Open thankyoulike.css and add at the end this code for a better formatted Thank You/Like button:

/* Custom */
a.add_tyl_button span{
	background-image: none;
	font-weight: bold;
}
a.add_tyl_button span:before {
	content: "\f164";
	font-family:FontAwesome;
}
a.del_tyl_button span{
	background-image: none;
	font-weight: normal;
}
a.del_tyl_button span:before {
	content: "\f165";
	font-family:FontAwesome;
}
.tyllist {
	background-color: #d5d5d5;
}

5. Save the file
6. Click Templates on the left.
7. Select your BootBB Templates
8. Select Thank You/Like Templates and then open thankyoulike_member_profile
9. replace all content with the one from file 

thankyoulike_member_profile.txt

10. Save the template.