Note from Panayot:

jquery.counterup.min.js
waypoints.min.js

are not used anymore. They are loaded in the index template from cdn, but will be kept here for backup.
See https://github.com/ciromattia/jquery.counterup

npm.js does not seem to be referenced anywhere in the theme. Not sure what is it's purpose.